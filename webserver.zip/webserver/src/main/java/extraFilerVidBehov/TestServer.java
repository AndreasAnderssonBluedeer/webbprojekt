package extraFilerVidBehov;

import java.io.IOException;
import java.io.InputStream;
import javax.xml.bind.JAXBContext;
import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.StatusLine;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.HttpClients;

public class TestServer {
	
		public static void main(String[] args) throws IOException {
		}
	

}
